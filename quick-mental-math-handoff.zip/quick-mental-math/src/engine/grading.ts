import type { Problem } from '../skills/types';

/** Turns keypad (or typed) input into a number. "$1,234.5" -> 1234.5. */
export function parseAnswer(input: string): number | null {
  const s = input.replace(/[$,\s]/g, '');
  if (!/^-?(\d+\.?\d*|\.\d+)$/.test(s)) return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

/**
 * Estimate problems pass within their tolerance; whole-number answers must
 * match exactly; money and decimals match to the cent ("9.6" == "9.60").
 */
export function isCorrect(problem: Problem, given: number): boolean {
  if (problem.tolerance !== undefined) {
    return Math.abs(given - problem.answer) <= problem.tolerance + 1e-9;
  }
  if (problem.answerKind === 'integer') return given === problem.answer;
  return Math.abs(given - problem.answer) < 0.005;
}

/** Display form of the expected answer, e.g. "$9.60" or "1,225". */
export function formatAnswer(problem: Problem): string {
  const v = problem.answer;
  const text =
    problem.answerKind === 'money' && !Number.isInteger(v)
      ? v.toFixed(2)
      : String(Math.round(v * 100) / 100);
  const [whole = '', frac] = text.split('.');
  const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return (problem.unit ?? '') + grouped + (frac ? '.' + frac : '') + (problem.suffix ?? '');
}

/** "$13.52 to $16.52" — the accepted range for an estimate problem. */
export function formatRange(problem: Problem): string | null {
  if (problem.tolerance === undefined) return null;
  const lo = Math.max(0, problem.answer - problem.tolerance);
  const hi = problem.answer + problem.tolerance;
  return formatAnswer({ ...problem, answer: round2(lo) }) + ' to ' + formatAnswer({ ...problem, answer: round2(hi) });
}

function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}
